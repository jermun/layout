package com.example.layout;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private Button b1, b2, b3;
    private ImageView i1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        i1 = findViewById(R.id.img1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disableEnable();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideShow(false);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideShow(true);
            }
        });
    }

    private void disableEnable() {
        if (b2.isEnabled()) {
            b2.setEnabled(false);
            b3.setEnabled(false);
        } else {
            b2.setEnabled(true);
            b3.setEnabled(true);
        }
    }

    private void hideShow(boolean value) {
        if (value) {
            i1.setVisibility(View.VISIBLE);
        } else {
            i1.setVisibility(View.INVISIBLE);
        }
    }
}